classdef GapVisualizer < matlab.System
    % GapVisualizer  Shows the current network, detected coverage gaps, and
    % ranked candidate node locations in one figure. Separate from
    % EnvironmentVisualizer and CoverageMap -- both keep working unchanged.
    %
    % Inputs:
    %   nodePositions  - 3x3, existing ground node positions
    %   gapX, gapY     - 1xMaxPoints (NaN-padded), from GapDetector
    %   gapCount       - scalar
    %   candidateX, candidateY - 1xMaxCandidates (NaN-padded), from CandidatePlacement
    %   candidateCount - scalar
    %
    % No outputs -- draws its own figure.
    %
    % Legend: existing nodes = blue circles, gap survey points = red
    % squares, candidate locations = black stars (larger, sized/labeled by
    % rank so higher-priority candidates stand out).

    properties
        AreaSize  = [1000 1000]
    end

    properties (Access = private)
        FigureHandle
        AxesHandle
    end

    methods (Access = protected)
        function setupImpl(obj)
            if evalin('base', 'exist(''areaSize'', ''var'')')
                obj.AreaSize = evalin('base', 'areaSize');
            end
            obj.FigureHandle = figure('Name', 'EmergencyNetwork - Gap Analysis', ...
                'NumberTitle', 'off', 'Color', 'w');
            obj.AxesHandle = axes('Parent', obj.FigureHandle);
        end

        function stepImpl(obj, nodePositions, gapX, gapY, gapCount, ...
                candidateX, candidateY, candidateCount)
            ax = obj.AxesHandle;
            cla(ax);
            hold(ax, 'on'); grid(ax, 'on'); box(ax, 'on'); axis(ax, 'equal');
            xlim(ax, [0 obj.AreaSize(1)]);
            ylim(ax, [0 obj.AreaSize(2)]);
            xlabel(ax, 'X (metres)');
            ylabel(ax, 'Y (metres)');
            title(ax, sprintf('Gap Analysis - %d gap points, %d candidate(s)', ...
                gapCount, candidateCount));

            

            % --- Existing ground nodes: blue circles ---
            plot(ax, nodePositions(:,1), nodePositions(:,2), 'o', ...
                'MarkerFaceColor', 'b', 'MarkerEdgeColor', 'k', 'MarkerSize', 9, ...
                'DisplayName', 'Existing node');

            % --- Gap survey points: red squares ---
            validGaps = ~isnan(gapX(1:gapCount));
            plot(ax, gapX(validGaps), gapY(validGaps), 's', ...
                'MarkerFaceColor', 'r', 'MarkerEdgeColor', 'k', 'MarkerSize', 9, ...
                'DisplayName', 'Coverage gap');

            % --- Candidate locations: best candidate clearly highlighted ---
            for i = 1:candidateCount
                if i == 1
                    % Best candidate: prominent gold star with bold label
                    plot(ax, candidateX(i), candidateY(i), 'p', ...
                        'MarkerFaceColor', [1 0.8 0], 'MarkerEdgeColor', [0 0.2 0.8], ...
                        'MarkerSize', 24, 'LineWidth', 2.5);
                    text(ax, candidateX(i) + 18, candidateY(i), ...
                        sprintf('★ BEST CANDIDATE (Rank 1)'), ...
                        'FontSize', 10, 'FontWeight', 'bold', 'Color', [0.8 0.4 0]);
                else
                    plot(ax, candidateX(i), candidateY(i), 'p', ...
                        'MarkerFaceColor', 'k', 'MarkerEdgeColor', 'y', ...
                        'MarkerSize', 16, 'LineWidth', 1.5);
                    text(ax, candidateX(i) + 15, candidateY(i), ...
                        sprintf('Candidate %d', i), ...
                        'FontSize', 9, 'FontWeight', 'bold', 'Color', 'k');
                end
            end

            legend(ax, {'Existing node', 'Coverage gap'}, 'Location', 'bestoutside');
            drawnow;
        end

        function resetImpl(~)
        end

        function num = getNumInputsImpl(~)
            num = 7;
        end
        function num = getNumOutputsImpl(~)
            num = 0;
        end
    end
end